package net.redborder.utils.generators;

import java.util.Map;

public interface Generator {
    Map<String, Object> generate();
}
