package net.redborder.utils.types;

public interface Type {
    Object get();
}
